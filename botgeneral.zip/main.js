const Discord = require('discord.js');

const client = new Discord.Client();

const prefix = '!';

var servers = {};


client.once('ready', () => {
    console.log('El bot de La Unión Rp está online');
});


client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'ip'){
        message.channel.send('IP DEL SERVIDOR: connect 25.87.19.22');
    }
});

client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'instagram'){
        message.channel.send('El instagram del servidor es: https://instagram.com/launion_rp/');
    }
});

client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'tiktok'){
        message.channel.send('El tiktok del servidor es: https://tiktok.com/@union_rp');
    }
});

client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'programador'){
        message.channel.send('El programador de este bot es Geas#6539');
    }
});


client.login('NzU2NjE4NzA1NjkzMzExMDE3.X2UeFA.HkBgRNhzaSjGLKUedPjqJ2PWXfc');